# Authority Builder Studio · Release 3.1

Four studios under one roof, wearing the yasmincronin.com look and working like Canva: Emails, Photos (the Brand Shot Studio), Planner and Prompts, plus Projects, a built-in brand kit, workspaces, member access with an admin panel, and Netlify functions bridging Claude and your email platforms.

## What changed in 3.1

Built from research into why content calendars and email campaigns stall for coaches and creators: no time ("a second job"), blank days, adapting each idea for every platform, staying consistent, not knowing what's working, email production that drags, broken links and spam-folder worries, and AI output people don't trust or understand.

- **A copywriting tutor inside every email.** Each paragraph is tagged with its job (hook, story, turn, proof, offer, deadline, call to action, open loop, the thread, sign-off, P.S.), shown in the margin (dots on phones). Tap a tag for a plain-English explanation. If someone deletes a key part of the framework (call to action, link, open loop, hook, thread, merge tag), a friendly card explains what it was for and offers **Put it back**, **Rewrite it with the tutor** or **I meant to**. The Tutor tab shows the email's job, a framework check (✓ / ✕) and **Ask the tutor**, a short-answer AI chat that can rewrite one part and drop it in with **Use this**. The guard is free and always on; the AI chat can be switched off in admin.
- **Image slots in email drafts.** Where the builder recommends a picture, the draft shows an image block in place: size (shows at 600 px, export 1200 × 600 JPG under 200 KB), editable alt text, the image prompt, Open Photos, a local preview upload and a web-link field. "＋ Image" adds one anywhere. Copies and downloads keep an `[IMAGE: alt]` line; drafts sent to Kit or MailerLite include the image when it has a link, otherwise a visible reminder to add it.
- **Check before sending.** Subject and preview length, links still left as placeholders, one clear ask, first-name fallback, never-say words, shouting, image alt text and link, length, plus the Gmail and Yahoo sender rules. **Your links**: set each `[BOOKING LINK]`-style placeholder once for the whole campaign.
- **Campaigns land on the Planner.** One click schedules every email on its day (read from the builder's timing), linked back to the editor; running it again updates instead of duplicating.
- **A planner with a plan.** Month focus and goal; 3–5 content pillars with target shares and a mix meter (pillars and Attract / Nurture / Convert); posts-per-week rhythm with this week's gaps highlighted and a streak; **Fill my gaps**, **One idea → a week**, **Batch day** and **What's working** (results logged on published posts and emails: clicks, replies and sales rather than opens, since Apple Mail Privacy Protection made opens unreliable).
- **Welcome back, rebuilt.** 8-box code entry that takes a pasted code, a remembered email ("Not you?"), clear messages for signed out, expired, paused, ended, locked and wrong code, a Lost your code? link to your support email, and members return to the page they were heading for.
- **Studio admin, rebuilt.** Overview (members, active this week, never signed in, generations today, a setup-health checklist that links to the Netlify environment settings), Members (search, filters, sort, tags, notes, end dates, per-member daily limits, bulk add, CSV export), Invite (editable template with preview), Settings (support email, daily generation limit, AI tutor switch, default access length) and Activity.
- **Safer server.** Codes are stored hashed (older codes convert on next sign-in); 5 wrong tries per email or IP locks sign-in for 15 minutes; pausing or ending access takes effect immediately, including for AI calls; optional daily generation limits protect your Anthropic spend; usage is counted per member, per day (Sydney time) and per kind.

## What changed in 3.0

- **The yasmincronin.com look.** Paper field `#F5F5F0`, night `#101D15` with a fine dot grid, ink `#141B15`, lime CTA pills `#A0CF5D` with dark text, lime-hi `#B8E452` for the YC mark, pale lime `#D5EAB8` numerals on dark bands, moss `#6F9445` / moss-ink `#3E6A1F` for labels and "selected". Plus Jakarta Sans everywhere, 800-weight headlines with tight tracking and a lime highlighter under the key word. No pink, no gold, no serif. Every token lives in `:root` in `assets/app.css`; `assets/shell.css` is generated from it for the Brand Shot Studio.
- **Works like Canva.** A slim icon rail (bottom tab bar on phones), a top bar with search across studios, templates and your projects (press `/`), a **Create** menu, and an account menu. A 60-second **quick setup** (name, business type, archetypes, palette) sets the brand once for every studio.
- **Home.** "What will you create today?" with a big search, one-tap shortcuts, recent designs, a template row, your week and your brand at a glance.
- **Emails, now an editor.** A template gallery (37 campaigns, filter by category, search), then an editor: questions on the left with "Use an example" on every one, the campaign on a canvas in the middle as real email pages. Edit subject, preview and body in place (merge tags shown as chips), switch subject lines and A/B versions, undo, copy, download, or send as a draft to Kit or MailerLite. Every edit saves itself.
- **Projects.** Everything made in any studio lands in Projects automatically, with thumbnails, filters, search and sort. Email campaigns reopen in the editor exactly as you left them.
- **Photos, same app, new look.** Yasmin's full Prompt Studio runs inside the suite rail, prefilled from the profile so the wizard is skipped. Her colours are remapped to night and lime; her engine, prompts and fixes from 2.0 are untouched.
- **Everything else matched.** Planner, Prompts, Settings and the brand kit, sign-in, admin and all 37 builders (when opened on their own) share the same type, colours and controls. Builders link back to the Studio.

## Deploy (5 minutes)

1. **Netlify → Add new site → Deploy manually** and drag this whole folder in (or connect it as a repo). `netlify.toml` and `package.json` are configured; functions bundle automatically.
2. **Environment variables** (Site settings → Environment variables):

| Variable | Required | What it does |
|---|---|---|
| `ANTHROPIC_API_KEY` | Yes | Powers every generator through the site's own `/api/generate` proxy. The key never reaches a browser. |
| `SITE_SECRET` | For member access | Any long random string. Setting it **turns the gate on**: every page requires sign-in and every API call requires a valid session. Without it the site runs open (good for your own testing). |
| `ADMIN_KEY` | For the admin panel | Your personal admin password for `/admin.html`. |

3. Deploy. Then open `/admin.html`, enter your admin key, and add your first member.

## How member access works

- You add members in the admin panel (one at a time or a pasted list). Each gets a personal 8-character access code, **shown once** with a copy-ready invite. Only a scrambled (hashed) version is stored, so a lost code is reset, never re-shown.
- They sign in at `/login.html` with email + code and get a 30-day signed session on that device. Five wrong tries locks sign-in for that email (and IP) for 15 minutes.
- **Pause** stops access immediately (sign-in and every AI call). An **end date** does the same automatically. **Reset code** kills a lost code. **Remove** deletes them.
- **Daily limit** (Settings, or per member): the most generations a member can run per day, Sydney time. 0 means unlimited.
- Enforcement is server-side: `/api/generate` and `/api/provider` reject calls without a valid session, so your Anthropic spend is protected, not just the pages.
- Members, settings, usage and the activity log are stored in Netlify Blobs (built into your Netlify site, no external database).

## What's here

| Path | What it is |
|---|---|
| `index.html` | Home: search, create shortcuts, recent designs, templates, the week ahead, your brand. |
| `brandshot/` | Photos (the Brand Shot Studio): Yasmin's full Prompt Studio (4,437 prompts, 152 niches, 21 image and video AIs) running inside the suite rail. `brandshot.html` redirects here. |
| `emailbank.html` | Emails: the 37-template gallery and the canvas editor (`?tool=2.1` opens a template, `?gen=<id>` reopens a project). |
| `library.html` | Projects: every generation from every studio, per workspace. |
| `promptbank.html` | Prompt Bank: 22 master prompts across 8 categories (hooks, captions, story/bio, offers, email one-offs, repurposing, visibility, outreach), auto-personalised with the workspace brand kit, runnable in place or copyable into any AI. |
| `calendar.html` | Content Planner: month focus, content pillars and mix meter, rhythm and gaps, Fill my gaps, One idea → a week, Batch day, What's working, plus the full scheduler — post composer with per-platform variants and char limits, AI write + remix in the member's voice, media, drag-and-drop rescheduling, month/week/queue views, filters, posting-time slots, publish packs per platform, automation webhook, CSV and .ics (with reminders) export. Per-workspace. |
| `tools/*.html` | The 37 builders (the Email Bank's engine), in the release 3.1 skin when opened on their own, reading the active workspace on open: archetypes in 70/20/10 order, business type, sender name and platform arrive pre-selected. Their own accessibility dark mode still works. |
| `settings.html` | Workspaces (one per brand/client, agency-style), profile, brand kit with the 12-archetype selector, connections, preferences, usage, data export/erase. |
| `login.html` | The member gate: segmented code entry, remembered email, every state explained, lost-code help, returns to the page the member wanted. |
| `admin.html` | Studio admin: overview and setup health, members (tags, notes, end dates, daily limits, bulk add, CSV), invite template, settings, activity. |
| `netlify/functions/` | `generate` (Claude proxy with per-member checks, daily limits and usage), `provider` (Kit/MailerLite draft bridge), `auth` (status/login/verify with throttling), `admin` (members, settings, health, activity), `_shared` (tokens, stores, hashing, events). |

## Verified before shipping (3.1)

- Server: 85 checks against the real function code with an in-memory store (every admin action, throttling and unlock, end dates, hashed-code migration, immediate pause, daily limits, usage by kind, settings, health, open mode).
- Sign-in and admin end to end against the real handlers: 52 checks (wrong key, unlock, health, add with code shown once, bulk add with duplicates, edit, settings → lost-code link, wrong code, lockout, pasted code → back to the page, paused, signed out, phone layouts).
- Emails editor: 44 checks for images, tutor, guard, send check, links and Add to Planner, plus the 32-check editor suite, all 37 campaigns generating and rendering, and all 37 prompts building.
- Planner: 51 checks (focus, pillars and mix, stages, gaps, Fill my gaps, One idea → a week, Batch day, results and What's working, the Emails link, phone).
- Suite, Projects and Brand Shot: 40, 14 and 17 checks; every page clean at 1440 px and 390 px with zero console errors.

## The MCP plan

The send desk contract (`POST /api/provider`) is shaped like an MCP tool call. Production path: an MCP server exposing `create_draft_broadcast` per provider (ActiveCampaign, Klaviyo, Flodesk next), swapped in with no front-end changes.

## Honest limits

- Sessions and workspaces live per browser/device. Same member on two devices = sign in twice; workspaces don't sync between devices yet. The step up is a small user-data API on the same Blobs store.
- Usage counters and the activity log can miss an increment when two calls land at exactly the same moment (Blobs has no atomic counters). Fine for limits and trends, not for billing.
- The framework tags are rule-based, so an unusual paragraph can fall back to "Builds the case". Uploaded email images are preview-only in that browser; sending needs the image's web address.
- Results in What's working are entered by hand; nothing is pulled from Instagram, LinkedIn or your email platform yet.
- Provider keys are the member's own, held in their browser and passed per-request. Nothing is stored server-side.
