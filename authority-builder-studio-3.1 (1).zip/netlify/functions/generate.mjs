// Claude generation proxy — streaming edition.
// The studio tools POST the same body they would send to the Anthropic Messages API and
// read back a normal Messages-API-shaped JSON object. Under the hood this function:
//   1. calls Anthropic with stream:true and accumulates the text deltas,
//   2. streams whitespace keepalive bytes to the browser every second so the response
//      starts immediately (long generations survive serverless sync time limits;
//      leading whitespace is valid before JSON, so response.json() still works),
//   3. falls back through a chain of known-good models if the requested model id
//      is rejected upstream, so a stale model name can never kill a generation.
// Set ANTHROPIC_API_KEY in Netlify: Site configuration -> Environment variables.

import { verifyToken, authRequired, membersStore, getJSON, getSettings, readUsage, usageToday, bumpUsage, isEnded } from "./_shared.mjs";

const MODEL_FALLBACKS = ["claude-sonnet-4-5", "claude-sonnet-4-0", "claude-3-7-sonnet-latest"];

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  if (req.method !== "POST") return json({ error: { message: "POST only" } }, 405);
  let email = null, member = null;
  if (authRequired()) {
    const v = verifyToken(req.headers.get("x-ab-token"));
    if (!v.ok) return json({ error: { type: "auth", message: "Sign in to use this. Your session may have expired: open the site again and log back in." }, ok: false }, 401);
    email = v.email || null;
  }

  let body;
  try { body = await req.json(); } catch { return json({ error: { message: "Invalid JSON" } }, 400); }
  // what kind of generation this is, for the admin's usage view; never sent upstream
  const kind = /^[a-z][a-z-]{1,19}$/.test(String(body.abKind || "")) ? body.abKind : "build";

  // access is checked on every call, so pausing or removing a member takes effect immediately
  if (email) {
    try {
      const m = await getJSON(await membersStore(), email);
      if (!m) return json({ error: { type: "access", message: "Your access has been removed. Ask the person who runs your program." }, ok: false }, 403);
      if (m.status !== "active") return json({ error: { type: "access", message: "Your access is paused, so the studio can't write right now. Ask the person who runs your program." }, ok: false }, 403);
      if (isEnded(m)) return json({ error: { type: "access", message: "Your access has ended. Ask the person who runs your program if you'd like to keep going." }, ok: false }, 403);
      member = m;
    } catch { /* member store unreachable: never block a generation on it */ }
    try {
      const s = await getSettings();
      const cap = member && member.dailyCap != null ? Number(member.dailyCap) : Number(s.dailyCap || 0);
      if (cap > 0 && usageToday(await readUsage(email)) >= cap) {
        return json({ error: { type: "cap", message: "You've used today's " + cap + " generations. It resets at midnight Sydney time." }, ok: false }, 429);
      }
    } catch { /* usage store unreachable: never block a generation on it */ }
  }

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return json({ error: { type: "config", message: "ANTHROPIC_API_KEY is not set on this site. Add it in Netlify environment variables and redeploy." } }, 500);

  const requested = /^claude-/.test(String(body.model || "")) ? body.model : MODEL_FALLBACKS[0];
  const models = [requested, ...MODEL_FALLBACKS.filter(m => m !== requested)];
  const payload = {
    max_tokens: Math.min(Number(body.max_tokens) || 8000, 32000),
    messages: body.messages,
    stream: true,
  };
  if (body.system) payload.system = body.system;

  const encoder = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      const keepalive = setInterval(() => {
        try { controller.enqueue(encoder.encode(" ")); } catch { /* closed */ }
      }, 1000);
      const finish = (obj) => {
        clearInterval(keepalive);
        try { controller.enqueue(encoder.encode(JSON.stringify(obj))); } catch { /* closed */ }
        try { controller.close(); } catch { /* closed */ }
      };
      try {
        let lastErr = null;
        for (const model of models) {
          const r = await fetch("https://api.anthropic.com/v1/messages", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-api-key": key,
              "anthropic-version": "2023-06-01",
            },
            body: JSON.stringify({ ...payload, model }),
          });
          if (!r.ok) {
            let errBody = null;
            try { errBody = await r.json(); } catch { /* not json */ }
            const msg = (errBody && errBody.error && errBody.error.message) || ("Upstream " + r.status);
            // model-not-found or invalid model -> try the next fallback; anything else is final
            if ((r.status === 404 || r.status === 400) && /model/i.test(msg)) { lastErr = { status: r.status, msg }; continue; }
            finish({ error: { message: msg }, status: r.status });
            return;
          }
          // accumulate the SSE stream into a Messages-API-shaped result
          const reader = r.body.getReader();
          const decoder = new TextDecoder();
          let buf = "", text = "", stopReason = "end_turn";
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split("\n");
            buf = lines.pop();
            for (const line of lines) {
              if (!line.startsWith("data:")) continue;
              const dataStr = line.slice(5).trim();
              if (!dataStr || dataStr === "[DONE]") continue;
              let ev;
              try { ev = JSON.parse(dataStr); } catch { continue; }
              if (ev.type === "content_block_delta" && ev.delta && typeof ev.delta.text === "string") text += ev.delta.text;
              if (ev.type === "message_delta" && ev.delta && ev.delta.stop_reason) stopReason = ev.delta.stop_reason;
              if (ev.type === "error") { finish({ error: { message: (ev.error && ev.error.message) || "stream error" } }); return; }
            }
          }
          try { await bumpUsage(email || "_open", kind); } catch { /* usage is a nice-to-have */ }
          finish({ content: [{ type: "text", text }], stop_reason: stopReason, model });
          return;
        }
        finish({ error: { message: "No available model accepted this request: " + (lastErr ? lastErr.msg : "unknown") }, status: 502 });
      } catch (e) {
        finish({ error: { message: "Upstream error: " + e.message }, status: 502 });
      }
    },
  });

  return new Response(stream, { status: 200, headers: { "Content-Type": "application/json", ...cors() } });
};

function cors() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, X-AB-Token",
  };
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...cors() } });
}

export const config = { path: "/api/generate" };
