// Shared helpers for the studio's functions.
// Tokens are HMAC-signed with SITE_SECRET. If SITE_SECRET is not set, the site runs OPEN
// (prototype mode): no gate, no checks.
import crypto from "node:crypto";

/* ── clock (tests can time-travel by setting globalThis.__AB_NOW to a function) ── */
export function now() {
  return typeof globalThis.__AB_NOW === "function" ? globalThis.__AB_NOW() : Date.now();
}
/** YYYY-MM-DD in Sydney time: daily usage and access end dates follow the studio's home timezone. */
export function sydneyDate(ms = now()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Australia/Sydney", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date(ms));
}
export function sydneyDaysAgo(n, ms = now()) {
  return sydneyDate(ms - n * 864e5);
}
/** true once the member's access end date (YYYY-MM-DD, inclusive) is in the past, Sydney time */
export function isEnded(m, ms = now()) {
  return !!(m && m.expiresAt && /^\d{4}-\d{2}-\d{2}/.test(m.expiresAt) && sydneyDate(ms) > String(m.expiresAt).slice(0, 10));
}

/* ── sessions ── */
export function authRequired() {
  return !!process.env.SITE_SECRET;
}
export function signToken(email, days = 30) {
  const payload = Buffer.from(JSON.stringify({ e: email.toLowerCase(), x: now() + days * 864e5 })).toString("base64url");
  const sig = crypto.createHmac("sha256", process.env.SITE_SECRET).update(payload).digest("base64url");
  return payload + "." + sig;
}
export function verifyToken(token) {
  try {
    if (!process.env.SITE_SECRET) return { ok: true, open: true };
    if (!token) return { ok: false, reason: "missing" };
    const [payload, sig] = String(token).split(".");
    const expect = crypto.createHmac("sha256", process.env.SITE_SECRET).update(payload).digest("base64url");
    const a = Buffer.from(sig || ""), b = Buffer.from(expect);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { ok: false, reason: "bad-signature" };
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (now() > data.x) return { ok: false, reason: "expired" };
    return { ok: true, email: data.e };
  } catch (e) {
    return { ok: false, reason: "invalid" };
  }
}

/* ── storage: Netlify Blobs, or an in-memory stand-in for local tests (AB_TEST_STORE=memory) ── */
const _mem = {};
export async function store(name) {
  if (globalThis.__AB_STORE_FAIL) throw new Error("store unavailable (simulated)");
  if (process.env.AB_TEST_STORE === "memory") {
    const m = (_mem[name] = _mem[name] || {});
    return {
      get: async k => (Object.prototype.hasOwnProperty.call(m, k) ? m[k] : null),
      set: async (k, v) => { m[k] = String(v); },
      delete: async k => { delete m[k]; },
      list: async (opts = {}) => ({ blobs: Object.keys(m).filter(k => !opts.prefix || k.startsWith(opts.prefix)).map(key => ({ key })) }),
    };
  }
  const { getStore } = await import("@netlify/blobs");
  return getStore({ name, consistency: "strong" });
}
export function _resetMemory() { for (const k of Object.keys(_mem)) delete _mem[k]; }
export async function membersStore() { return store("members"); }

export async function getJSON(st, key, fallback = null) {
  const raw = await st.get(key);
  if (raw == null) return fallback;
  try { return JSON.parse(raw); } catch { return fallback; }
}
export async function setJSON(st, key, val) { await st.set(key, JSON.stringify(val)); }

/* ── member records ── */
export function makeCode() {
  // 8 chars from an unambiguous alphabet: no 0, O, 1, I or L
  const a = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
  return Array.from(crypto.randomBytes(8)).map(b => a[b % a.length]).join("");
}
export function normCode(c) { return String(c || "").toUpperCase().replace(/[^A-Z0-9]/g, ""); }
/** only a scrambled version of each code is stored */
export function hashCode(email, code) {
  return crypto.createHash("sha256").update(String(email).trim().toLowerCase() + ":" + normCode(code)).digest("hex");
}
export function codeMatches(m, email, code) {
  const c = normCode(code);
  if (!c) return false;
  if (m.codeHash) {
    const a = Buffer.from(hashCode(email, c)), b = Buffer.from(String(m.codeHash));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  if (m.code) { // members created before 3.1 kept a plaintext code; migrated on their next sign-in
    const a = Buffer.from(c), b = Buffer.from(normCode(m.code));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  return false;
}
/** what the admin panel may see of a member: never the code or its hash */
export function publicMember(m) {
  const out = { ...m };
  delete out.code; delete out.codeHash;
  out.tags = Array.isArray(out.tags) ? out.tags : [];
  out.ended = isEnded(m);
  return out;
}

/* ── studio settings (separate store from members) ── */
export const DEFAULT_INVITE =
  "Hi {name},\n\nYou're in! Your Authority Builder Studio access is ready.\n\n" +
  "1. Open {link}\n2. Sign in with {email}\n3. Enter your access code: {code}\n\n" +
  "The code is yours alone, so keep it somewhere safe. Your emails, brand photos, planner and prompts are waiting for you.\n\nSee you inside.";
export const DEFAULT_SETTINGS = { supportEmail: "", dailyCap: 0, tutor: true, accessDays: 0, inviteTemplate: DEFAULT_INVITE };
export async function getSettings() {
  try {
    const st = await store("studio");
    const s = await getJSON(st, "settings", {});
    return { ...DEFAULT_SETTINGS, ...(s || {}) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

/* ── activity log: the last 300 events, newest first ── */
export async function logEvent(type, data = {}) {
  try {
    const st = await store("studio");
    const list = await getJSON(st, "events", []);
    list.unshift({ t: new Date(now()).toISOString(), type, ...data });
    await setJSON(st, "events", list.slice(0, 300));
  } catch { /* the log must never break the action it records */ }
}

/* ── usage: one record per member, per Sydney day, per kind of generation ── */
export async function readUsage(email) {
  const st = await store("usage");
  return getJSON(st, email || "_open", { days: {}, total: 0 });
}
export function usageToday(u, ms = now()) {
  const d = (u && u.days && u.days[sydneyDate(ms)]) || {};
  return Object.values(d).reduce((a, b) => a + (Number(b) || 0), 0);
}
export function usageSummary(u, ms = now()) {
  const today = sydneyDate(ms), week = {}, todayKinds = (u && u.days && u.days[today]) || {};
  let weekTotal = 0;
  for (let i = 0; i < 7; i++) {
    const d = (u && u.days && u.days[sydneyDaysAgo(i, ms)]) || {};
    for (const [k, v] of Object.entries(d)) { week[k] = (week[k] || 0) + (Number(v) || 0); weekTotal += Number(v) || 0; }
  }
  return { today: usageToday(u, ms), todayByKind: todayKinds, week: weekTotal, weekByKind: week, total: (u && u.total) || 0, last: (u && u.last) || null };
}
export async function bumpUsage(email, kind = "build") {
  const st = await store("usage");
  const key = email || "_open";
  const u = await getJSON(st, key, { days: {}, total: 0 });
  const day = sydneyDate();
  u.days = u.days || {};
  u.days[day] = u.days[day] || {};
  u.days[day][kind] = (u.days[day][kind] || 0) + 1;
  u.total = (u.total || 0) + 1;
  u.last = new Date(now()).toISOString();
  const cutoff = sydneyDaysAgo(35);
  for (const d of Object.keys(u.days)) if (d < cutoff) delete u.days[d];
  await setJSON(st, key, u);
  return u;
}

/* ── http ── */
export function clientIp(req, context) {
  const h = k => (req.headers.get(k) || "").split(",")[0].trim();
  return (context && context.ip) || h("x-nf-client-connection-ip") || h("x-forwarded-for") || "unknown";
}
export function cors() {
  return { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type, X-AB-Token, X-Admin-Key" };
}
export function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...cors() } });
}
export function validEmail(e) { return /^[^@\s,;<>]+@[^@\s,;<>]+\.[^@\s,;<>]{2,}$/.test(String(e || "")); }
