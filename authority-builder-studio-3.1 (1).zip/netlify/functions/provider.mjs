// Email provider bridge.
// Creates a DRAFT in the user's email platform. It never sends to subscribers.
// The user's provider API key is passed per-request from the browser and is not stored.
//
// Supported today:
//   kit         -> POST https://api.kit.com/v4/broadcasts        (draft broadcast)
//   mailerlite  -> POST https://connect.mailerlite.com/api/campaigns (draft campaign)
//
// This is the prototype bridge. The production path is an MCP server exposing
// create-draft tools per provider; this function keeps the same contract so the
// front end will not need to change.

import { verifyToken, authRequired } from "./_shared.mjs";

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  if (req.method !== "POST") return json({ ok: false, error: "POST only" }, 405);
  if (authRequired()) {
    const v = verifyToken(req.headers.get("x-ab-token"));
    if (!v.ok) return json({ error: { type: "auth", message: "Sign in to use this. Your session may have expired: open the site again and log back in." }, ok: false }, 401);
  }


  let b;
  try { b = await req.json(); } catch { return json({ ok: false, error: "Invalid JSON" }, 400); }

  const { provider, apiKey, subject, preview, bodyHtml, bodyText, fromEmail, groupName } = b;
  if (!provider || !apiKey || !subject || !(bodyHtml || bodyText)) {
    return json({ ok: false, error: "Missing provider, apiKey, subject or body" }, 400);
  }

  try {
    if (provider === "kit") {
      // Kit (ConvertKit) v4: creating a broadcast without send_at leaves it as a draft.
      const r = await fetch("https://api.kit.com/v4/broadcasts", {
        method: "POST",
        headers: { "Content-Type": "application/json", "X-Kit-Api-Key": apiKey },
        body: JSON.stringify({
          subject,
          preview_text: preview || "",
          content: bodyHtml || textToHtml(bodyText),
          public: false,
        }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) return json({ ok: false, error: kitErr(data, r.status) }, r.status);
      const id = data?.broadcast?.id;
      return json({
        ok: true,
        provider: "kit",
        draftId: id || null,
        openUrl: id ? `https://app.kit.com/campaigns/${id}` : "https://app.kit.com/campaigns",
        note: "Draft broadcast created in Kit. Open it, pick your audience, and schedule it yourself.",
      });
    }

    if (provider === "mailerlite") {
      // MailerLite new API: campaigns are created as drafts.
      const r = await fetch("https://connect.mailerlite.com/api/campaigns", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + apiKey,
          "Accept": "application/json",
        },
        body: JSON.stringify({
          name: subject.slice(0, 120),
          type: "regular",
          emails: [{
            subject,
            from_name: b.fromName || "Me",
            from: fromEmail || "",
            content: bodyHtml || textToHtml(bodyText),
          }],
        }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) return json({ ok: false, error: mlErr(data, r.status) }, r.status);
      const id = data?.data?.id;
      return json({
        ok: true,
        provider: "mailerlite",
        draftId: id || null,
        openUrl: "https://dashboard.mailerlite.com/campaigns/status/draft",
        note: "Draft campaign created in MailerLite. Open it, choose recipients, and schedule it yourself.",
      });
    }

    return json({ ok: false, error: "Provider not supported yet. Kit and MailerLite work today; the rest arrive with the MCP bridge." }, 400);
  } catch (e) {
    return json({ ok: false, error: "Bridge error: " + e.message }, 502);
  }
};

function textToHtml(t) {
  const esc = String(t || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return esc.split(/\n{2,}/).map(p => "<p>" + p.replace(/\n/g, "<br>") + "</p>").join("\n");
}
function kitErr(d, s) {
  if (s === 401) return "Kit rejected the API key. Check Settings -> Developer -> V4 Keys in your Kit account.";
  return (d && (d.errors ? JSON.stringify(d.errors) : d.message)) || ("Kit error " + s);
}
function mlErr(d, s) {
  if (s === 401) return "MailerLite rejected the API key. Check Integrations -> API in your MailerLite account.";
  if (s === 422 && d?.errors) return "MailerLite validation: " + JSON.stringify(d.errors) + ". A verified sender email address is usually the missing piece.";
  return (d && d.message) || ("MailerLite error " + s);
}
function cors() {
  return { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type" };
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...cors() } });
}

export const config = { path: "/api/provider" };
