// Member sign-in and session checks.
// Members are created in the admin panel; each gets a personal 8-character access code.
// Failed attempts are throttled per email and per IP: 5 in 15 minutes locks sign-in for 15 minutes.
import {
  authRequired, signToken, verifyToken, membersStore, store, getJSON, setJSON, json, cors, now,
  codeMatches, hashCode, normCode, isEnded, getSettings, logEvent, clientIp, validEmail,
} from "./_shared.mjs";

const MAX_FAILS = 5, WINDOW = 15 * 60e3, LOCK = 15 * 60e3;

async function throttleState(st, key) {
  const t = await getJSON(st, key, { fails: [], lockedUntil: 0 });
  t.fails = (t.fails || []).filter(x => now() - x < WINDOW);
  return t;
}
function minutesLeft(until) { return Math.max(1, Math.ceil((until - now()) / 60e3)); }
function endDate(m) {
  try { return new Date(String(m.expiresAt).slice(0, 10) + "T12:00:00Z").toLocaleDateString("en-AU", { day: "numeric", month: "long", year: "numeric" }); }
  catch { return String(m.expiresAt).slice(0, 10); }
}

export default async (req, context) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  if (req.method !== "POST") return json({ ok: false, error: "POST only" }, 405);

  let b; try { b = await req.json(); } catch { return json({ ok: false, error: "Invalid JSON" }, 400); }

  if (b.action === "status") {
    const s = await getSettings();
    return json({ ok: true, authRequired: authRequired(), support: s.supportEmail || "", tutor: s.tutor !== false });
  }

  if (b.action === "verify") {
    const v = verifyToken(b.token);
    if (v.ok && authRequired() && v.email) {
      try { // revoking or ending access takes effect immediately, not when the 30-day session runs out
        const m = await getJSON(await membersStore(), v.email);
        if (!m) return json({ ok: false, open: false, email: v.email, reason: "removed" });
        if (m.status !== "active") return json({ ok: false, open: false, email: v.email, reason: "paused" });
        if (isEnded(m)) return json({ ok: false, open: false, email: v.email, reason: "ended" });
      } catch { /* store unreachable: trust the signed token rather than lock everyone out */ }
    }
    return json({ ok: v.ok, open: !authRequired(), email: v.email || null, reason: v.reason || null });
  }

  if (b.action === "login") {
    if (!authRequired()) return json({ ok: true, open: true, token: null, note: "This site is running open: no login needed." });
    const email = String(b.email || "").trim().toLowerCase();
    const code = normCode(b.code);
    if (!email || !code) return json({ ok: false, code: "missing", field: !email ? "email" : "code", error: !email ? "Add the email your invite was sent to." : "Add your 8-character access code." }, 400);
    if (!validEmail(email)) return json({ ok: false, code: "missing", field: "email", error: "That doesn't look like an email address. Check for a typo." }, 400);

    let members, thr;
    try { members = await membersStore(); thr = await store("throttle"); }
    catch (e) { return json({ ok: false, code: "unavailable", error: "Sign-in is having a moment. Try again in a minute." }, 503); }

    const ip = clientIp(req, context);
    const kE = "e:" + email, kI = "ip:" + ip;
    const tE = await throttleState(thr, kE), tI = await throttleState(thr, kI);
    const lockedUntil = Math.max(tE.lockedUntil || 0, tI.lockedUntil || 0);
    if (lockedUntil > now()) {
      const mins = minutesLeft(lockedUntil);
      return json({ ok: false, code: "locked", minutes: mins, retryAt: new Date(lockedUntil).toISOString(),
        error: "Too many tries, so sign-in is paused for " + mins + " minute" + (mins === 1 ? "" : "s") + ". This keeps your account safe." }, 429);
    }

    async function fail(codeName, message, status, extra = {}) {
      for (const [k, t] of [[kE, tE], [kI, tI]]) {
        t.fails.push(now());
        if (t.fails.length >= MAX_FAILS) { t.lockedUntil = now() + LOCK; t.fails = []; }
        await setJSON(thr, k, t);
      }
      const locked = Math.max(tE.lockedUntil || 0, tI.lockedUntil || 0) > now();
      await logEvent(locked ? "login-locked" : "login-failed", { email, reason: codeName });
      if (locked) {
        return json({ ok: false, code: "locked", minutes: 15, retryAt: new Date(Math.max(tE.lockedUntil, tI.lockedUntil)).toISOString(),
          error: "Too many tries, so sign-in is paused for 15 minutes. This keeps your account safe." }, 429);
      }
      const left = MAX_FAILS - Math.max(tE.fails.length, tI.fails.length);
      return json({ ok: false, code: codeName, left, error: message, ...extra }, status);
    }

    try {
      const m = await getJSON(members, email);
      if (!m) return fail("not-member", "That email isn't on the member list. Use the address your invite was sent to.", 401, { field: "email" });
      if (!codeMatches(m, email, code)) return fail("bad-code", "That code doesn't match. Codes are 8 characters and never use 0, O, 1, I or L.", 401, { field: "code" });
      // the right code, but access is off: say so plainly (these don't count as failed tries)
      if (m.status !== "active") {
        await logEvent("login-blocked", { email, reason: "paused" });
        return json({ ok: false, code: "paused", error: "Your access is paused. Ask the person who runs your program to switch it back on." }, 403);
      }
      if (isEnded(m)) {
        await logEvent("login-blocked", { email, reason: "ended" });
        return json({ ok: false, code: "ended", endedOn: String(m.expiresAt).slice(0, 10), error: "Your access ended on " + endDate(m) + ". Ask the person who runs your program if you'd like to keep going." }, 403);
      }

      if (m.code && !m.codeHash) { m.codeHash = hashCode(email, code); } // migrate a pre-3.1 plaintext code
      delete m.code;
      m.lastLogin = new Date(now()).toISOString();
      m.logins = (m.logins || 0) + 1;
      await setJSON(members, email, m);
      await setJSON(thr, kE, { fails: [], lockedUntil: 0 });
      await logEvent("login", { email, name: m.name || "" });
      return json({ ok: true, token: signToken(email), name: m.name || "", email });
    } catch (e) {
      return json({ ok: false, code: "unavailable", error: "Sign-in is having a moment: " + e.message }, 500);
    }
  }

  return json({ ok: false, error: "Unknown action" }, 400);
};

export const config = { path: "/api/auth" };
