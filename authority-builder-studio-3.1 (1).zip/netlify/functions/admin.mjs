// Admin API. Every call needs the X-Admin-Key header matching the ADMIN_KEY env var.
// Access codes are returned ONCE (on add, bulk-add and reset-code) and only a hash is stored.
import {
  membersStore, store, getJSON, setJSON, makeCode, hashCode, json, cors, authRequired, now, sydneyDate,
  publicMember, getSettings, DEFAULT_SETTINGS, logEvent, readUsage, usageSummary, validEmail, isEnded,
} from "./_shared.mjs";

const DATE = /^\d{4}-\d{2}-\d{2}$/;
class Bad extends Error {} // a validation problem the admin can fix: answered with a 400 and a plain message

function cleanTags(t) {
  const arr = Array.isArray(t) ? t : String(t || "").split(",");
  const out = [];
  for (const x of arr) {
    const v = String(x).trim().replace(/\s+/g, " ").slice(0, 24);
    if (v && !out.some(o => o.toLowerCase() === v.toLowerCase())) out.push(v);
  }
  return out.slice(0, 8);
}
function cleanCap(v) {
  if (v === "" || v === null || v === undefined) return null; // null = use the studio default
  const n = Math.floor(Number(v));
  if (!Number.isFinite(n) || n < 0 || n > 10000) throw new Bad("The daily limit has to be a number from 0 to 10,000 (0 means unlimited).");
  return n;
}
function cleanDate(v) {
  if (v === "" || v === null || v === undefined) return "";
  const d = String(v).slice(0, 10);
  if (!DATE.test(d)) throw new Bad("Access end dates look like 2026-12-31.");
  return d;
}
function plusDays(days) {
  return sydneyDate(now() + days * 864e5);
}
function newMember(email, b, settings) {
  const code = makeCode();
  const m = {
    email, name: String(b.name || "").trim().slice(0, 80), tags: cleanTags(b.tags), notes: String(b.notes || "").slice(0, 1000),
    expiresAt: b.expiresAt ? cleanDate(b.expiresAt) : (settings.accessDays > 0 ? plusDays(settings.accessDays) : ""),
    dailyCap: cleanCap(b.dailyCap), codeHash: hashCode(email, code), status: "active", addedAt: new Date(now()).toISOString(), logins: 0,
  };
  return { m, code };
}
/** "email, name" · "name <email>" · tab or semicolon separated · one per line */
function parseLine(line) {
  const l = String(line).trim();
  if (!l) return null;
  const angle = l.match(/^(.*?)<\s*([^>\s]+@[^>\s]+)\s*>\s*$/);
  if (angle) return { email: angle[2].toLowerCase(), name: angle[1].replace(/["',;]/g, "").trim() };
  const parts = l.split(/\s*[,;\t]\s*/);
  const ei = parts.findIndex(p => /@/.test(p));
  if (ei < 0) return { email: "", name: l, raw: l };
  const email = parts[ei].replace(/^mailto:/i, "").trim().toLowerCase();
  const name = parts.filter((_, i) => i !== ei).join(" ").replace(/["']/g, "").trim();
  return { email, name };
}

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors() });
  if (req.method !== "POST") return json({ ok: false, error: "POST only" }, 405);

  const adminKey = process.env.ADMIN_KEY;
  if (!adminKey) return json({ ok: false, error: "ADMIN_KEY is not set on this site. Add it in Netlify environment variables to enable the admin panel." }, 500);
  if (req.headers.get("x-admin-key") !== adminKey) return json({ ok: false, code: "wrong-key", error: "That admin key doesn't match the ADMIN_KEY set on Netlify." }, 401);

  let b; try { b = await req.json(); } catch { return json({ ok: false, error: "Invalid JSON" }, 400); }

  if (b.action === "health") {
    let storeOk = true, counts = { members: 0, active: 0, paused: 0, ended: 0, never: 0 };
    try {
      const st = await membersStore();
      const { blobs } = await st.list();
      for (const bl of blobs) {
        const m = await getJSON(st, bl.key); if (!m) continue;
        counts.members++;
        if (m.status !== "active") counts.paused++; else if (isEnded(m)) counts.ended++; else counts.active++;
        if (!m.logins) counts.never++;
      }
    } catch { storeOk = false; }
    const s = await getSettings();
    return json({ ok: true, checks: {
      anthropicKey: !!process.env.ANTHROPIC_API_KEY, siteSecret: !!process.env.SITE_SECRET, adminKey: true, store: storeOk, supportEmail: !!s.supportEmail,
    }, counts, authRequired: authRequired() });
  }

  let st;
  try { st = await membersStore(); }
  catch (e) { return json({ ok: false, error: "Member store unavailable: " + e.message }, 500); }

  const email = String(b.email || "").trim().toLowerCase();

  try {
    if (b.action === "list") {
      const out = [];
      const { blobs } = await st.list();
      await Promise.all(blobs.map(async bl => {
        const m = await getJSON(st, bl.key);
        if (!m) return;
        const pm = publicMember(m);
        try { pm.usage = usageSummary(await readUsage(m.email || bl.key)); } catch { pm.usage = usageSummary(null); }
        out.push(pm);
      }));
      out.sort((a, z) => (a.addedAt || "") < (z.addedAt || "") ? 1 : -1);
      let open = null;
      try { open = usageSummary(await readUsage("_open")); } catch { /* fine */ }
      return json({ ok: true, members: out, openUsage: open, authRequired: authRequired(), today: sydneyDate() });
    }

    if (b.action === "add") {
      if (!validEmail(email)) return json({ ok: false, error: "A real email address is the minimum." }, 400);
      if (await st.get(email)) return json({ ok: false, code: "duplicate", error: "Already a member. Reset their code if they've lost it." }, 409);
      const s = await getSettings();
      const { m, code } = newMember(email, b, s);
      await setJSON(st, email, m);
      await logEvent("member-added", { email, name: m.name });
      return json({ ok: true, member: { ...publicMember(m), code } }); // the code, once
    }

    if (b.action === "bulk-add") {
      const lines = Array.isArray(b.rows) ? b.rows.map(r => r && (r.email ? r : parseLine(String(r)))) : String(b.lines || "").split(/\r?\n/).map(parseLine);
      const rows = lines.filter(Boolean);
      if (!rows.length) return json({ ok: false, error: "Paste at least one line: email, name." }, 400);
      if (rows.length > 200) return json({ ok: false, error: "Up to 200 people at a time. Split the list and add the rest next." }, 400);
      const s = await getSettings(), seen = new Set(), results = [];
      for (const r of rows) {
        const e = String(r.email || "").trim().toLowerCase(), name = String(r.name || "").trim();
        if (!validEmail(e)) { results.push({ email: e || r.raw || "", name, status: "invalid" }); continue; }
        if (seen.has(e) || await st.get(e)) { results.push({ email: e, name, status: "duplicate" }); continue; }
        seen.add(e);
        const { m, code } = newMember(e, { name, tags: b.tags, expiresAt: b.expiresAt, dailyCap: b.dailyCap }, s);
        await setJSON(st, e, m);
        results.push({ email: e, name: m.name, status: "added", code });
      }
      const added = results.filter(r => r.status === "added").length;
      await logEvent("members-bulk-added", { count: added, skipped: results.length - added });
      return json({ ok: true, results, added });
    }

    if (b.action === "update") {
      const m = await getJSON(st, email);
      if (!m) return json({ ok: false, error: "No such member." }, 404);
      if ("name" in b) m.name = String(b.name || "").trim().slice(0, 80);
      if ("tags" in b) m.tags = cleanTags(b.tags);
      if ("notes" in b) m.notes = String(b.notes || "").slice(0, 1000);
      if ("expiresAt" in b) m.expiresAt = cleanDate(b.expiresAt);
      if ("dailyCap" in b) m.dailyCap = cleanCap(b.dailyCap);
      await setJSON(st, email, m);
      await logEvent("member-updated", { email, fields: Object.keys(b).filter(k => ["name", "tags", "notes", "expiresAt", "dailyCap"].includes(k)) });
      const pm = publicMember(m);
      try { pm.usage = usageSummary(await readUsage(email)); } catch { /* fine */ }
      return json({ ok: true, member: pm });
    }

    if (b.action === "reset-code") {
      const m = await getJSON(st, email);
      if (!m) return json({ ok: false, error: "No such member." }, 404);
      const code = makeCode();
      m.codeHash = hashCode(email, code); delete m.code;
      await setJSON(st, email, m);
      await logEvent("code-reset", { email });
      return json({ ok: true, member: { ...publicMember(m), code } }); // the new code, once
    }

    if (b.action === "revoke" || b.action === "restore") {
      const m = await getJSON(st, email);
      if (!m) return json({ ok: false, error: "No such member." }, 404);
      m.status = b.action === "revoke" ? "revoked" : "active";
      await setJSON(st, email, m);
      await logEvent(b.action === "revoke" ? "member-paused" : "member-restored", { email });
      return json({ ok: true, member: publicMember(m) });
    }

    if (b.action === "remove") {
      await st.delete(email);
      try { await (await store("usage")).delete(email); await (await store("throttle")).delete("e:" + email); } catch { /* fine */ }
      await logEvent("member-removed", { email });
      return json({ ok: true });
    }

    if (b.action === "settings-get") {
      return json({ ok: true, settings: await getSettings(), defaults: DEFAULT_SETTINGS });
    }

    if (b.action === "settings-set") {
      const cur = await getSettings(), next = { ...cur }, inS = b.settings || {};
      if ("supportEmail" in inS) {
        const v = String(inS.supportEmail || "").trim();
        if (v && !validEmail(v)) return json({ ok: false, field: "supportEmail", error: "The support email doesn't look right. Check for a typo." }, 400);
        next.supportEmail = v;
      }
      if ("dailyCap" in inS) {
        const n = Math.floor(Number(inS.dailyCap));
        if (!Number.isFinite(n) || n < 0 || n > 10000) return json({ ok: false, field: "dailyCap", error: "The daily limit has to be a number from 0 to 10,000 (0 means unlimited)." }, 400);
        next.dailyCap = n;
      }
      if ("tutor" in inS) next.tutor = !!inS.tutor;
      if ("accessDays" in inS) {
        const n = Math.floor(Number(inS.accessDays));
        if (!Number.isFinite(n) || n < 0 || n > 3650) return json({ ok: false, field: "accessDays", error: "Access length is a number of days from 0 to 3,650 (0 means no end date)." }, 400);
        next.accessDays = n;
      }
      if ("inviteTemplate" in inS) {
        const t = String(inS.inviteTemplate || "").slice(0, 2000);
        if (!t.trim()) next.inviteTemplate = DEFAULT_SETTINGS.inviteTemplate;
        else if (!/\{code\}/.test(t)) return json({ ok: false, field: "inviteTemplate", error: "The invite needs {code} in it, or members won't get their access code." }, 400);
        else next.inviteTemplate = t;
      }
      await setJSON(await store("studio"), "settings", next);
      await logEvent("settings-changed", { fields: Object.keys(inS) });
      return json({ ok: true, settings: next });
    }

    if (b.action === "activity") {
      let events = [];
      try { events = await getJSON(await store("studio"), "events", []); } catch { /* fine */ }
      const limit = Math.min(300, Math.max(1, Number(b.limit) || 100));
      return json({ ok: true, events: events.slice(0, limit) });
    }

    return json({ ok: false, error: "Unknown action" }, 400);
  } catch (e) {
    if (e instanceof Bad) return json({ ok: false, error: e.message }, 400);
    return json({ ok: false, error: "Admin action failed: " + (e && e.message) }, 500);
  }
};

export const config = { path: "/api/admin" };
