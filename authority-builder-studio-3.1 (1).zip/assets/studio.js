/* Shared shell v3: workspaces (agency-style), settings store, theme, Canva-style rail + top bar, search, quick setup, toast, usage. */
(function(){
"use strict";
var DEF={
  name:"", businessName:"", email:"",
  businessType:"", archetypes:[], look:"", brandColours:"", voiceNotes:"", neverSay:"",
  fromName:"", fromEmail:"",
  defaultImgPlatform:"", defaultEmailProvider:"kit",
  theme:"light", motion:"auto",
  hiddenStudios:[], customSkills:[],
  brand:{
    paletteId:"", colors:{bg:"#FFFFFF",text:"#1A1A1A",accent:"#4A4A4A",muted:"#8A8A8A",highlight:"#D9D9D9"},
    fontGroup:"", headingFont:"", bodyFont:"",
    images:{logo:"",logoDark:"",headshot:"",texture:""},
    components:[]
  }
};

/* ── Brand palettes · 22 palettes, bright-first. These are the MEMBER'S options —
      the kit starts neutral until they choose. Every text-on-background pair clears WCAG AA. ── */
var PALETTES=[
 /* bright & bold */
 {id:"coral-pop",n:"Coral Pop",bg:"#FFF9F5",text:"#26140E",accent:"#F04E30",muted:"#A08074",highlight:"#FFC63F",d:"Warm white, electric coral, a flash of sun. Instant energy."},
 {id:"ocean-bright",n:"Ocean Bright",bg:"#F4FBFD",text:"#0A2540",accent:"#0084C7",muted:"#6E8CA0",highlight:"#00C2D1",d:"Sea-glass white, vivid ocean blue, aqua spark. Fresh and clear."},
 {id:"citrus-punch",n:"Citrus Punch",bg:"#FFFDF4",text:"#2B1D06",accent:"#F0790A",muted:"#9C8A6A",highlight:"#FFD23F",d:"Sunlit white, tangerine, lemon pop. Impossible to scroll past."},
 {id:"emerald-pop",n:"Emerald Pop",bg:"#F3FBF6",text:"#0B2E1D",accent:"#0BA05F",muted:"#74937F",highlight:"#8CE8B4",d:"Minted white, vivid emerald, spring greens. Alive and optimistic."},
 {id:"violet-volt",n:"Violet Volt",bg:"#F9F7FF",text:"#1E1440",accent:"#6236FF",muted:"#8B84A8",highlight:"#C3B5FF",d:"Lilac-white, electric violet. Creative voltage."},
 {id:"fuchsia-bold",n:"Fuchsia Bold",bg:"#FFF7FB",text:"#33081F",accent:"#D6246E",muted:"#A0728A",highlight:"#FF87AB",d:"Petal white, fearless fuchsia. Confidence in colour form."},
 {id:"royal-cobalt",n:"Royal Cobalt",bg:"#F6F8FF",text:"#101B3E",accent:"#2450E5",muted:"#7C87A8",highlight:"#FFB53C",d:"Ice white, royal cobalt, amber wink. Sharp and premium."},
 {id:"aqua-mango",n:"Aqua & Mango",bg:"#F2FCFB",text:"#0E2E2B",accent:"#0E9E8E",muted:"#6F9490",highlight:"#FFA02E",d:"Fresh aqua teal against ripe mango. Tropical, modern."},
 {id:"sunshine-studio",n:"Sunshine Studio",bg:"#FFFCF0",text:"#2E2404",accent:"#D99400",muted:"#9C8F62",highlight:"#FF7847",d:"Cream, deep golden yellow, coral flare. Pure warmth."},
 {id:"bubblegum-sky",n:"Bubblegum & Sky",bg:"#FFF5F7",text:"#360D18",accent:"#E8386D",muted:"#A3707F",highlight:"#3EC3FF",d:"Blush white, bright pink, sky-blue pop. Playful, unmissable."},
 {id:"bold-contrast",n:"Bold Contrast",bg:"#F1FAEE",text:"#1D3557",accent:"#E63946",muted:"#577590",highlight:"#F4A261",d:"Ivory, deep blue, coral-red accent. Loud but readable."},
 /* warm & luxe lights */
 {id:"sunset-coral",n:"Sunset Coral",bg:"#FFF7F0",text:"#37231E",accent:"#D95627",muted:"#9A756A",highlight:"#F2B441",d:"Warm white, burnt coral, golden hour. Energetic optimism."},
 {id:"terracotta-studio",n:"Terracotta Studio",bg:"#F6EDE3",text:"#33231A",accent:"#C0562D",muted:"#9B7B63",highlight:"#E8A25C",d:"Warm sand, clay-fired terracotta. Mediterranean warmth."},
 {id:"desert-neutrals",n:"Desert Neutrals",bg:"#F5F0E6",text:"#2D2419",accent:"#8A6538",muted:"#8C7A5E",highlight:"#D9AE5F",d:"Cream, deep walnut, bright bronze. Luxury-editorial."},
 {id:"soft-luxe",n:"Soft Luxe",bg:"#FDF6F0",text:"#3D2E22",accent:"#B0704A",muted:"#9C7E6A",highlight:"#E0A87C",d:"Blush-cream, warm espresso, rose-gold. Quietly premium."},
 {id:"soft-feminine",n:"Soft Feminine",bg:"#FEF5F0",text:"#3D2732",accent:"#C2497A",muted:"#8A6471",highlight:"#FF9EB8",d:"Blush, plum text, bright rose. Warm and inviting."},
 /* crisp lights */
 {id:"mono",n:"Mono",bg:"#FFFFFF",text:"#0A0A0A",accent:"#000000",muted:"#6B6B6B",highlight:"#B3B3B3",d:"Pure monochrome. Gallery-clean, maximum contrast."},
 {id:"tech-minimal",n:"Tech Minimal",bg:"#FFFFFF",text:"#0A0A0A",accent:"#0052CC",muted:"#6B7280",highlight:"#33B1FF",d:"Pure white, near-black, cobalt. Engineered, sharp."},
 {id:"coastal",n:"Coastal",bg:"#F5F0E6",text:"#1E3A5F",accent:"#2563A8",muted:"#6B8091",highlight:"#5EB8D9",d:"Ivory, bright marine blue. Relaxed, composed."},
 {id:"jewel-tones",n:"Jewel Tones",bg:"#FAF6EE",text:"#1A1A2E",accent:"#0E7A44",muted:"#7A7A8E",highlight:"#C42E4C",d:"Ivory, midnight text, bright emerald and garnet. Rich."},
 /* darks */
 {id:"moody-editorial",n:"Moody Editorial",bg:"#1A1A1A",text:"#F2ECDF",accent:"#E3B76E",muted:"#9C8F7A",highlight:"#FFD9A0",d:"Near-black, warm ivory, glowing gold. Cinematic."},
 {id:"forest-dark",n:"Forest Dark",bg:"#0F1E16",text:"#EAE7E1",accent:"#D9B884",muted:"#8A9990",highlight:"#8FDCA9",d:"Deep forest, warm ivory, bright gold and mint. Grounded depth."}
];

/* ── Font groups · same taxonomy as the Origin Story Builder ── */
var FONT_GROUPS=[
 {id:"editorial-serif",n:"Editorial serif",ex:"Fraunces · Playfair · Canela",v:"luxurious, considered",head:"'Fraunces',Georgia,serif",body:"'Inter',sans-serif"},
 {id:"modern-sans",n:"Modern sans",ex:"Inter · Söhne · Neue Haas",v:"clean, premium",head:"'Inter',sans-serif",body:"'Inter',sans-serif"},
 {id:"bold-display",n:"Bold display",ex:"Druk · Migra · Archivo",v:"loud, provocative",head:"'Archivo Black','Inter',sans-serif",body:"'Inter',sans-serif"},
 {id:"friendly-rounded",n:"Friendly rounded",ex:"Recoleta · Poppins · DM Sans",v:"approachable, warm",head:"'Poppins',sans-serif",body:"'DM Sans','Inter',sans-serif"},
 {id:"tech-mono",n:"Tech mono",ex:"JetBrains Mono · IBM Plex",v:"technical, niche",head:"'JetBrains Mono',monospace",body:"'Inter',sans-serif"},
 {id:"handwritten",n:"Handwritten",ex:"script · personal",v:"personal, intimate",head:"'Caveat',cursive",body:"'Inter',sans-serif"},
 {id:"classic-serif",n:"Classic serif",ex:"Garamond · Cormorant",v:"timeless, authoritative",head:"'Cormorant Garamond',Georgia,serif",body:"'Inter',sans-serif"},
 {id:"geometric-sans",n:"Geometric sans",ex:"Futura · Gotham · Montserrat",v:"confident, structural",head:"'Montserrat',sans-serif",body:"'Inter',sans-serif"}
];

function brand(){
  var s=load(); var b=s.brand||{};
  var c=Object.assign({},DEF.brand.colors,b.colors||{});
  var fg=FONT_GROUPS.filter(function(f){return f.id===b.fontGroup;})[0];
  return {
    paletteId:b.paletteId||"", colors:c,
    fontGroup:b.fontGroup||"", fontGroupName:fg?fg.n:"",
    headingFont:(b.headingFont||"").trim()||(fg?fg.head:"'Inter',sans-serif"),
    bodyFont:(b.bodyFont||"").trim()||(fg?fg.body:"'Inter',sans-serif"),
    images:Object.assign({},DEF.brand.images,b.images||{}),
    components:(b.components||[]).slice()
  };
}
/* summary string the builders and Brand Shot consume as "brand colours" */
function brandColourLine(b){
  b=b||brand();
  return "background "+b.colors.bg+", text "+b.colors.text+", accent "+b.colors.accent+", muted "+b.colors.muted+(b.colors.highlight?", highlight "+b.colors.highlight:"");
}
/* email-safe HTML for a saved component, styled with the workspace brand */
function componentHTML(comp,b){
  b=b||brand(); var c=b.colors, f=comp.fields||{};
  var head='font-family:'+b.headingFont.replace(/"/g,"'")+';', body='font-family:'+b.bodyFont.replace(/"/g,"'")+';';
  switch(comp.type){
   case "signature":
    return '<table role="presentation" cellpadding="0" cellspacing="0" style="border-top:2px solid '+c.accent+';margin-top:24px;padding-top:14px"><tr>'
     +(b.images.headshot?'<td style="padding-right:14px"><img src="'+b.images.headshot+'" width="56" height="56" alt="" style="border-radius:50%;display:block"></td>':'')
     +'<td><div style="'+head+'font-weight:700;font-size:15px;color:'+c.text+'">'+esc(f.name||"")+'</div>'
     +(f.title?'<div style="'+body+'font-size:13px;color:'+c.muted+'">'+esc(f.title)+'</div>':'')
     +(f.link?'<div style="'+body+'font-size:13px;margin-top:4px"><a href="'+esc(f.link)+'" style="color:'+c.accent+'">'+esc(f.linkLabel||f.link)+'</a></div>':'')
     +'</td></tr></table>';
   case "button":
    return '<table role="presentation" cellpadding="0" cellspacing="0" style="margin:18px 0"><tr><td style="border-radius:10px;background:'+c.accent+'">'
     +'<a href="'+esc(f.url||"#")+'" style="'+head+'display:inline-block;padding:13px 26px;font-weight:700;font-size:15px;color:'+(c.bg||"#fff")+';text-decoration:none">'+esc(f.label||"Click here")+'</a></td></tr></table>';
   case "header":
    return '<div style="background:'+c.bg+';border-bottom:3px solid '+c.accent+';padding:18px 0;text-align:center">'
     +(b.images.logo?'<img src="'+b.images.logo+'" alt="'+esc(f.brandName||"")+'" style="max-height:44px;display:inline-block">':'<div style="'+head+'font-weight:800;font-size:19px;color:'+c.text+'">'+esc(f.brandName||"")+'</div>')
     +(f.tagline?'<div style="'+body+'font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:'+c.muted+';margin-top:5px">'+esc(f.tagline)+'</div>':'')+'</div>';
   case "footer":
    return '<div style="border-top:1px solid '+c.muted+'33;margin-top:28px;padding-top:16px;text-align:center;'+body+'font-size:12px;color:'+c.muted+'">'
     +(f.legal?esc(f.legal)+'<br>':'')+(f.address?esc(f.address)+'<br>':'')
     +'<span style="color:'+c.muted+'">You are receiving this because you signed up. Unsubscribe any time with the link in this email.</span></div>';
   case "testimonial":
    return '<div style="border-left:3px solid '+c.accent+';background:'+c.bg+';padding:14px 18px;margin:18px 0">'
     +'<div style="'+body+'font-size:15px;font-style:italic;color:'+c.text+'">“'+esc(f.quote||"")+'”</div>'
     +(f.who?'<div style="'+head+'font-size:13px;font-weight:700;color:'+c.accent+';margin-top:8px">— '+esc(f.who)+'</div>':'')+'</div>';
   case "divider":
    return '<div style="text-align:center;margin:22px 0"><span style="display:inline-block;width:64px;border-top:2px solid '+c.accent+'"></span></div>';
   default: /* custom */
    return String(f.html||"");
  }
}
/* plain-text fallback for the send desk (bodyText providers) */
function componentText(comp){
  var f=comp.fields||{};
  switch(comp.type){
   case "signature": return "—\n"+[f.name,f.title,f.linkLabel&&f.link?f.linkLabel+": "+f.link:f.link].filter(Boolean).join("\n");
   case "button": return (f.label||"Click here")+" → "+(f.url||"");
   case "header": return (f.brandName||"")+(f.tagline?"\n"+f.tagline:"");
   case "footer": return [f.legal,f.address].filter(Boolean).join("\n");
   case "testimonial": return "“"+(f.quote||"")+"”"+(f.who?" — "+f.who:"");
   case "divider": return "· · ·";
   default: return String(f.html||"").replace(/<[^>]+>/g,"").trim();
  }
}
var ARCHETYPES=[
 ["Sage","clear, evidence-led, teacherly"],
 ["Magician","transformative, sees what others miss"],
 ["Hero","direct, courageous, results-first"],
 ["Rebel","blunt, contrarian, breaks rules"],
 ["Creator","imaginative, craft-obsessed"],
 ["Ruler","assured, standards-led, composed"],
 ["Caregiver","warm, protective, steady"],
 ["Everyperson","plain-spoken, relatable, honest"],
 ["Lover","sensory, intimate, appreciative"],
 ["Jester","playful, quick, disarming"],
 ["Explorer","curious, restless, frontier-minded"],
 ["Innocent","optimistic, simple, sincere"]
];

function uid(){ return "ws_"+Math.random().toString(36).slice(2,9); }

function store(){
  var W;
  try{ W=JSON.parse(localStorage.getItem("ab_workspaces")||"null"); }catch(e){ W=null; }
  if(!W||!W.list||!W.list.length){
    // migrate v1 single-profile data if present
    var legacy={}; var legacyU={};
    try{ legacy=JSON.parse(localStorage.getItem("ab_settings")||"{}"); }catch(e){}
    try{ legacyU=JSON.parse(localStorage.getItem("ab_usage")||"{}"); }catch(e){}
    var id=uid();
    W={activeId:id,list:[{id:id,name:legacy.businessName||legacy.name||"My brand",
        settings:Object.assign({},DEF,legacy),
        usage:Object.assign({gen:0,drafts:0,favs:[],recents:[]},legacyU)}]};
    // migrate legacy provider keys into the first workspace
    ["kit","mailerlite"].forEach(function(p){
      var k=localStorage.getItem("ab_key_"+p);
      if(k){ localStorage.setItem("ab_key_"+p+"_"+id,k); localStorage.removeItem("ab_key_"+p); }
    });
    persist(W);
  }
  if(!W.list.some(function(w){return w.id===W.activeId;})) W.activeId=W.list[0].id;
  return W;
}
function persist(W){ localStorage.setItem("ab_workspaces",JSON.stringify(W)); }
function active(){ var W=store(); return W.list.filter(function(w){return w.id===W.activeId;})[0]; }

function load(){ return Object.assign({},DEF,active().settings); }
function save(s){
  var W=store();
  W.list.forEach(function(w){ if(w.id===W.activeId) w.settings=Object.assign({},DEF,s); });
  persist(W); apply(s);
}
function usage(){ return Object.assign({gen:0,drafts:0,favs:[],recents:[]},active().usage); }
function setUsage(u){
  var W=store();
  W.list.forEach(function(w){ if(w.id===W.activeId) w.usage=u; });
  persist(W);
}
function bump(k){ var u=usage(); u[k]=(u[k]||0)+1; setUsage(u); return u; }

/* provider keys, scoped per workspace */
function key(prov,val){
  var id=store().activeId, k="ab_key_"+prov+"_"+id;
  if(val===undefined) return localStorage.getItem(k)||"";
  if(val) localStorage.setItem(k,val); else localStorage.removeItem(k);
  return val;
}

/* workspace management */
function wsAll(){ return store().list.map(function(w){return {id:w.id,name:w.name};}); }
function wsActiveId(){ return store().activeId; }
function wsCreate(name){
  var W=store(); var id=uid();
  W.list.push({id:id,name:name||"New brand",settings:Object.assign({},DEF),usage:{gen:0,drafts:0,favs:[],recents:[]}});
  W.activeId=id; persist(W); return id;
}
function wsDuplicate(srcId,name){
  var W=store(); var src=W.list.filter(function(w){return w.id===srcId;})[0]; if(!src)return null;
  var id=uid();
  W.list.push({id:id,name:name||src.name+" copy",settings:JSON.parse(JSON.stringify(src.settings)),usage:{gen:0,drafts:0,favs:[],recents:[]}});
  W.activeId=id; persist(W); return id;
}
function wsSwitch(id){ var W=store(); if(W.list.some(function(w){return w.id===id;})){W.activeId=id;persist(W);apply(load());} }
function wsRename(id,name){ var W=store(); W.list.forEach(function(w){if(w.id===id)w.name=name;}); persist(W); }
function wsDelete(id){
  var W=store(); if(W.list.length<2) return false;
  ["kit","mailerlite"].forEach(function(p){ localStorage.removeItem("ab_key_"+p+"_"+id); });
  W.list=W.list.filter(function(w){return w.id!==id;});
  if(W.activeId===id)W.activeId=W.list[0].id;
  persist(W); return true;
}

function apply(s){
  document.documentElement.setAttribute("data-theme", s.theme==="dark"?"dark":"light");
  document.documentElement.setAttribute("data-motion", s.motion==="reduced"?"reduced":"auto");
}
function initials(s){
  var n=(s.name||s.businessName||"You").trim().split(/\s+/);
  return ((n[0]||"")[0]||"Y").toUpperCase()+((n[1]||"")[0]||"").toUpperCase();
}
/* ── release ── */
var VERSION="3.1";
var WHATS_NEW=[
 ["A tutor inside every email","Each paragraph shows its job: hook, story, call to action, open loop. Delete a key part by accident and the tutor offers to put it back, or ask it anything about the email."],
 ["Image slots in your emails","Emails that need a picture show where it goes, the size, the alt text and the image prompt. Add your image link and it goes out with the draft."],
 ["Check before you send","Links, subject length, preview text, never-say words, images and the Gmail and Yahoo rules, checked in one click. Set each link once for the whole campaign."],
 ["A planner that fills its own gaps","Set the month's focus and your content pillars, see your rhythm and the gaps, fill them with ideas, turn one idea into a week of posts, then batch-write."],
 ["Know what's working","Log results on published posts and emails (clicks, replies, sales) and see which pillars and channels earn their place."],
 ["Campaigns land in your Planner","One click puts every email in a campaign on its day, linked back to the editor."]
];
var ICONS={
 home:'<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
 shot:'<rect x="3" y="6" width="18" height="14" rx="3"/><circle cx="12" cy="13" r="3.5"/><path d="M8.5 6l1.5-2.5h4L15.5 6"/>',
 mail:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/>',
 cal:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
 bank:'<path d="M8 4h11a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H8"/><path d="M4 8h8M4 12h8M4 16h8"/>',
 lib:'<rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/>',
 brand:'<path d="M12 3a9 9 0 1 0 0 18c1.2 0 2-.9 2-2 0-.6-.2-1-.5-1.4-.3-.4-.5-.8-.5-1.3 0-1 .8-1.8 1.8-1.8H17a4 4 0 0 0 4-4c0-4.1-4-7.5-9-7.5z"/><circle cx="7.5" cy="11" r="1.2"/><circle cx="10" cy="7" r="1.2"/><circle cx="14.5" cy="7" r="1.2"/>',
 cog:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
 out:'<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l5-5-5-5M15 12H4"/>',
 search:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 spark:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
 arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
 back:'<path d="M19 12H5M11 6l-6 6 6 6"/>',
 copy:'<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>',
 down:'<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
 send:'<path d="M21 3 10 14M21 3l-7 18-4-7-7-4z"/>',
 edit:'<path d="M4 20h4L19 9a2.8 2.8 0 0 0-4-4L4 16z"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
 help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5h.01"/>',
 trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
 check:'<path d="m5 12 5 5 9-10"/>',
 x:'<path d="M6 6l12 12M18 6 6 18"/>',
 undo:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
 bulb:'<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>'
};
function icon(k){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(ICONS[k]||"")+'</svg>';}
/* relative root so links work from /brandshot/ and from file:// previews */
function root(){return /\/brandshot\//.test(location.pathname)?"../":"";}
var MARK='<span class="yc" aria-hidden="true">YC</span>';

/* ── the Canva-style shell: icon rail + top bar (search · workspace · Create · account) ── */
var NAV=[
 {k:"home",ic:"home",t:"Home",h:"index.html"},
 {k:"emailbank",ic:"mail",t:"Emails",h:"emailbank.html"},
 {k:"brandshot",ic:"shot",t:"Photos",h:"brandshot/index.html"},
 {k:"calendar",ic:"cal",t:"Planner",h:"calendar.html"},
 {k:"promptbank",ic:"bank",t:"Prompts",h:"promptbank.html"},
 {k:"library",ic:"lib",t:"Projects",h:"library.html"}
];
function sidebar(activePage,opts){
  opts=opts||{};
  var s=load(), W=store(), R=root();
  if(activePage==="library"&&/emailbank/.test(location.pathname))activePage="library";
  var rail=document.createElement("aside");
  rail.className="rail"+(opts.fixed?" fixed":""); rail.setAttribute("aria-label","Studios");
  rail.innerHTML='<a class="logo" href="'+R+'index.html" title="Home">'+MARK+'</a>'+
    NAV.filter(function(n){return !hid(n.k);}).map(function(n){return ri(R+n.h,n.ic,n.t,activePage===n.k);}).join("")+
    '<span class="sp"></span>'+
    ri(R+"settings.html#brandkit","brand","Brand",activePage==="brand","x-m")+
    ri(R+"settings.html","cog","Settings",activePage==="settings","x-m")+
    '<button class="ri x-m" type="button" data-wn><span class="ic">'+icon("spark")+'</span>What’s new'+(seenVersion()?'':'<span class="dot"></span>')+'</button>';
  var top=document.createElement("header");
  top.className="topbar"+(opts.fixed?" fixed":"");
  var wsOpts=W.list.map(function(w){return '<option value="'+w.id+'"'+(w.id===W.activeId?" selected":"")+'>'+esc(w.name)+'</option>';}).join("")+'<option value="__new">＋ New workspace…</option>';
  top.innerHTML=
    '<a class="tb-logo" href="'+R+'index.html" aria-label="Home">'+MARK+'</a>'+
    '<div class="tb-search wrap-rel" role="search"><span class="sic">'+icon("search")+'</span>'+
      '<input id="abSearch" type="search" autocomplete="off" placeholder="Search campaigns, prompts and your projects" aria-label="Search everything" aria-controls="abCmd" aria-expanded="false"><kbd>/</kbd>'+
      '<div class="pop cmd" id="abCmd" role="listbox"></div></div>'+
    '<div class="tb-right">'+
      '<button class="tb-icon tb-mobile-search" type="button" aria-label="Search" id="abSearchBtn">'+icon("search")+'</button>'+
      '<select class="tb-ws" id="wsSwitch" aria-label="Workspace">'+wsOpts+'</select>'+
      '<div class="wrap-rel"><button class="btn tb-create" type="button" id="abCreate" aria-haspopup="menu" aria-expanded="false">'+icon("plus")+'<span>Create</span></button>'+
        '<div class="pop menu" id="abCreateMenu" role="menu">'+createMenu(R)+'</div></div>'+
      '<div class="wrap-rel"><button class="tb-avatar" type="button" id="abMe" aria-haspopup="menu" aria-expanded="false" aria-label="Account">'+esc(initials(s))+'</button>'+
        '<div class="pop menu" id="abMeMenu" role="menu">'+meMenu(s,R)+'</div></div>'+
    '</div>';
  var host=opts.host||document.querySelector(".shell");
  if(opts.fixed){document.body.classList.add("ab-fixed-shell");document.body.prepend(top);document.body.prepend(rail);}
  else{host.prepend(top);host.prepend(rail);}
  wireShell(rail,top,W,R);wireLede();
  function ri(h,ic,t,on,cls){return '<a class="ri'+(on?" on":"")+(cls?" "+cls:"")+'" href="'+h+'"'+(on?' aria-current="page"':'')+'><span class="ic">'+icon(ic)+'</span>'+t+'</a>';}
  function hid(k){return (s.hiddenStudios||[]).indexOf(k)>-1&&activePage!==k;}
}
function createMenu(R){
  var it=[["mail","Email campaign","Pick from 37 templates",R+"emailbank.html","#EAF2DC"],
    ["spark","Welcome sequence","5 emails for new subscribers",R+"emailbank.html?tool=2.1","#F1F6E8"],
    ["shot","Brand photo prompt","4,437 scenes, your brand built in",R+"brandshot/index.html","#F4F2E4"],
    ["cal","Plan my month","AI maps a month of posts",R+"calendar.html","#E9F0EB"],
    ["bank","Hooks, bios and captions","Master prompts in your voice",R+"promptbank.html","#EFEFEA"]];
  return it.map(function(i){return '<a role="menuitem" href="'+i[3]+'"><span class="mi" style="background:'+i[4]+'">'+icon(i[0])+'</span><span>'+i[1]+'<small>'+i[2]+'</small></span></a>';}).join("")+
    '<hr><button type="button" role="menuitem" data-qs><span class="mi" style="background:var(--lime)">'+icon("brand")+'</span><span>Set up my brand<small>60 seconds, used everywhere</small></span></button>';
}
function meMenu(s,R){
  return '<div class="who"><span class="yc" style="width:38px;height:38px;font-size:.8rem;background:var(--night);color:var(--lime-hi)">'+esc(initials(s))+'</span><span><b>'+esc(s.name||"Your profile")+'</b><span>'+esc(active().name)+' · Founder</span></span></div><hr>'+
    '<a role="menuitem" href="'+R+'settings.html#brandkit"><span class="mi">'+icon("brand")+'</span>Brand kit</a>'+
    '<a role="menuitem" href="'+R+'settings.html"><span class="mi">'+icon("cog")+'</span>Settings</a>'+
    '<a role="menuitem" href="'+R+'library.html"><span class="mi">'+icon("lib")+'</span>Projects</a>'+
    '<button type="button" role="menuitem" data-wn><span class="mi">'+icon("spark")+'</span>What’s new in '+VERSION+'</button>'+
    '<button type="button" role="menuitem" data-qs><span class="mi">'+icon("user")+'</span>Quick brand setup</button>'+
    (localStorage.getItem("ab_token")?'<hr><button type="button" role="menuitem" data-out><span class="mi">'+icon("out")+'</span>Sign out</button>':'');
}
function wireLede(){
  var l=document.querySelector(".main > .lede");
  if(l)l.addEventListener("click",function(){l.classList.toggle("open");});
}
function wireShell(rail,top,W,R){
  function toggle(btn,pop,force){
    var on=force!=null?force:!pop.classList.contains("on");
    document.querySelectorAll(".pop.on").forEach(function(p){if(p!==pop)p.classList.remove("on");});
    pop.classList.toggle("on",on);if(btn)btn.setAttribute("aria-expanded",String(on));
  }
  var cb=top.querySelector("#abCreate"),cm=top.querySelector("#abCreateMenu"),mb=top.querySelector("#abMe"),mm=top.querySelector("#abMeMenu");
  cb.addEventListener("click",function(e){e.stopPropagation();toggle(cb,cm);});
  mb.addEventListener("click",function(e){e.stopPropagation();toggle(mb,mm);});
  document.addEventListener("click",function(e){if(!e.target.closest(".wrap-rel"))document.querySelectorAll(".pop.on").forEach(function(p){p.classList.remove("on");});});
  document.addEventListener("keydown",function(e){if(e.key==="Escape")document.querySelectorAll(".pop.on").forEach(function(p){p.classList.remove("on");});});
  [rail,top].forEach(function(el){
    el.querySelectorAll("[data-wn]").forEach(function(b){b.addEventListener("click",function(){toggle(null,mm,false);whatsNew();});});
    el.querySelectorAll("[data-qs]").forEach(function(b){b.addEventListener("click",function(){document.querySelectorAll(".pop.on").forEach(function(p){p.classList.remove("on");});quickSetup();});});
    el.querySelectorAll("[data-out]").forEach(function(b){b.addEventListener("click",signOut);});
  });
  top.querySelector("#wsSwitch").addEventListener("change",function(){
    if(this.value==="__new"){var name=prompt("Name the new workspace (a brand, a client, a profile):","New brand");
      if(name){wsCreate(name);location.reload();}else{this.value=W.activeId;}}
    else{wsSwitch(this.value);location.reload();}
  });
  // shadow under the top bar once the page scrolls
  window.addEventListener("scroll",function(){top.classList.toggle("scrolled",window.scrollY>4);},{passive:true});
  wireSearch(top,R);
}

/* ── global search: studios, campaigns, projects, actions ── */
function wireSearch(top,R){
  var inp=top.querySelector("#abSearch"),box=top.querySelector("#abCmd"),wrap=top.querySelector(".tb-search"),act=-1;
  function ensureMeta(cb){
    if(window.TOOLS_META)return cb();
    var sc=document.createElement("script");sc.src=R+"assets/tools-meta.js";sc.onload=cb;sc.onerror=cb;document.head.appendChild(sc);
  }
  function item(href,ci,t,sub,bg){return '<a class="cmd-i" role="option" href="'+href+'"><span class="ci"'+(bg?' style="background:'+bg+'"':'')+'>'+ci+'</span><span>'+t+(sub?'<small>'+sub+'</small>':'')+'</span></a>';}
  function render(){
    box.innerHTML=cmdHTML(inp.value,R);act=-1;
  }
  function open(){ensureMeta(render);box.classList.add("on");inp.setAttribute("aria-expanded","true");}
  inp.addEventListener("focus",open);
  inp.addEventListener("input",function(){ensureMeta(render);box.classList.add("on");});
  inp.addEventListener("keydown",function(e){cmdKeys(e,box,function(a){act=a;},function(){return act;});
    if(e.key==="Escape"){box.classList.remove("on");inp.blur();wrap.classList.remove("open");}
  });
  document.addEventListener("keydown",function(e){
    if(e.key==="/"&&!/INPUT|TEXTAREA|SELECT/.test((document.activeElement||{}).tagName||"")&&!document.activeElement.isContentEditable){e.preventDefault();wrap.classList.add("open");inp.focus();}
  });
  document.addEventListener("click",function(e){if(!e.target.closest(".tb-search")&&!e.target.closest("#abSearchBtn")){box.classList.remove("on");wrap.classList.remove("open");}});
  var mb=top.querySelector("#abSearchBtn");
  if(mb)mb.addEventListener("click",function(){wrap.classList.add("open");inp.focus();});
}
function cmdKeys(e,box,setAct,getAct){
  var its=box.querySelectorAll(".cmd-i"),act=getAct();
  if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();if(!its.length)return;act=(act+(e.key==="ArrowDown"?1:-1)+its.length)%its.length;its.forEach(function(x,i){x.classList.toggle("act",i===act);});its[act].scrollIntoView({block:"nearest"});setAct(act);}
  if(e.key==="Enter"){var t=its[act>-1?act:0];if(t){e.preventDefault();location.href=t.getAttribute("href");}}
}
function cmdHTML(qRaw,R){
    R=R==null?root():R;
    function item(href,ci,t,sub,bg){return '<a class="cmd-i" role="option" href="'+href+'"><span class="ci"'+(bg?' style="background:'+bg+'"':'')+'>'+ci+'</span><span>'+t+(sub?'<small>'+sub+'</small>':'')+'</span></a>';}
    var q=String(qRaw||"").trim().toLowerCase(),html="";
    var studios=[["Email campaigns","37 templates","emailbank.html","mail","#EAF2DC"],["Brand photo prompts","4,437 scenes","brandshot/index.html","shot","#F4F2E4"],
      ["Content planner","Your month","calendar.html","cal","#E9F0EB"],["Prompt bank","Master prompts","promptbank.html","bank","#EFEFEA"],
      ["Projects","Everything you've made","library.html","lib","#F1F6E8"],["Brand kit","Colours, fonts, voice","settings.html#brandkit","brand","#EAF2DC"],["Settings","Workspaces, connectors","settings.html","cog","#EFEFEA"]];
    var st=studios.filter(function(x){return !q||(x[0]+" "+x[1]).toLowerCase().indexOf(q)>-1;});
    if(st.length)html+='<div class="cmd-g">Go to</div>'+st.slice(0,q?4:7).map(function(x){return item(R+x[2],icon(x[3]),esc(x[0]),esc(x[1]),x[4]);}).join("");
    var tm=(window.TOOLS_META||[]).filter(function(t){return q&&(t.n+" "+t.t+" "+t.d+" "+t.folder).toLowerCase().indexOf(q)>-1;}).slice(0,6);
    if(tm.length)html+='<div class="cmd-g">Email templates</div>'+tm.map(function(t){return item(R+"emailbank.html?tool="+t.n,esc(t.n),esc(t.t),esc(t.d),"#EAF2DC");}).join("");
    var gs=gens().filter(function(g){return q&&(g.title+" "+g.text).toLowerCase().indexOf(q)>-1;}).slice(0,5);
    if(gs.length)html+='<div class="cmd-g">Your projects</div>'+gs.map(function(g){return item(R+"library.html?open="+g.id,icon(g.src==="brandshot"?"shot":g.src==="emailbank"?"mail":"bank"),esc(g.title),new Date(g.ts).toLocaleDateString("en-AU",{day:"numeric",month:"short"}),"#F1F6E8");}).join("");
    if(q)html+='<div class="cmd-g">Create</div>'+item(R+"emailbank.html?q="+encodeURIComponent(q),icon("mail"),"Find “"+esc(q)+"” in email templates","",null)+item(R+"brandshot/index.html",icon("shot"),"Browse brand photos","",null);
    return html||'<div class="cmd-empty">Nothing yet. Try “launch”, “welcome” or “black friday”.</div>';
}

/* ── What's new ── */
function whatsNew(){
  var m=document.getElementById("abWN");
  if(!m){
    m=document.createElement("div");m.id="abWN";m.className="ab-modal";m.setAttribute("role","dialog");m.setAttribute("aria-modal","true");m.setAttribute("aria-labelledby","abWNt");
    m.innerHTML='<div class="box"><div class="box-head"><div><div class="eyebrow" style="margin-bottom:4px">Release '+VERSION+'</div><h3 id="abWNt">What’s new</h3></div><button class="x" type="button" aria-label="Close">✕</button></div><div class="box-body">'+
      WHATS_NEW.map(function(w,i){return '<div class="wn-item"><span class="n">0'+(i+1)+'</span><span><b>'+esc(w[0])+'</b><span>'+esc(w[1])+'</span></span></div>';}).join("")+
      '<div style="margin-top:16px;text-align:right"><button class="btn small" type="button" id="abWNok">Got it '+icon("arrow")+'</button></div></div></div>';
    document.body.appendChild(m);
    var close=function(){m.classList.remove("on");try{localStorage.setItem("ab_seen_version",VERSION);}catch(e){}document.querySelectorAll(".ri .dot").forEach(function(d){d.remove();});};
    m.querySelector(".x").addEventListener("click",close);
    m.querySelector("#abWNok").addEventListener("click",close);
    m.addEventListener("click",function(e){if(e.target===m)close();});
    document.addEventListener("keydown",function(e){if(e.key==="Escape"&&m.classList.contains("on"))close();});
  }
  m.classList.add("on");
}
function seenVersion(){try{return localStorage.getItem("ab_seen_version")===VERSION;}catch(e){return true;}}
function profileComplete(s){s=s||load();return !!(s.name&&s.businessType&&(s.archetypes||[]).length);}

/* ── 60-second brand setup: name → business → archetypes → colours ── */
var BIZ=[["Coach","1:1 and group"],["Consultant","advice and done-with-you"],["Course creator","programs and courses"],["Service business","done-for-you"],["Membership","community or club"],["Content creator","audience-first"],["Author","books and speaking"],["Therapist","or practitioner"],["Trainer","or educator"],["Wellness","body and mind"],["SaaS","software"],["E-commerce","physical products"],["Designer","visual work"],["Writer","or copywriter"],["Property","real estate"],["Advisor","finance, legal"],["Other","something else"]];
var BIZ_VAL={"Membership":"Membership","Content creator":"Creator","Therapist":"Therapist","Trainer":"Trainer"};
function quickSetup(onDone){
  var s=load(),step=0,m=document.getElementById("abQS");
  var d={name:s.name||"",biz:s.businessName||"",type:s.businessType||"",arcs:(s.archetypes||[]).slice(),pal:(s.brand||{}).paletteId||""};
  if(m)m.remove();
  m=document.createElement("div");m.id="abQS";m.className="ab-modal";m.setAttribute("role","dialog");m.setAttribute("aria-modal","true");m.setAttribute("aria-label","Quick brand setup");
  m.innerHTML='<div class="box" style="width:min(680px,100%)"><div class="box-head"><div class="eyebrow" style="margin:0">Quick brand setup</div><button class="x" type="button" aria-label="Close">✕</button></div><div class="box-body" id="qsBody"></div></div>';
  document.body.appendChild(m);
  var body=m.querySelector("#qsBody");
  function close(){m.classList.remove("on");setTimeout(function(){m.remove();},200);}
  m.querySelector(".x").addEventListener("click",close);
  m.addEventListener("click",function(e){if(e.target===m)close();});
  function prog(){return '<div class="qs-prog">'+[0,1,2,3].map(function(i){return '<i'+(i<=step?' class="on"':'')+'></i>';}).join("")+'</div>';}
  function foot(nextLabel){return '<div class="qs-foot">'+(step?'<button class="btn ghost" type="button" data-b>'+icon("back")+'Back</button>':'')+'<span class="sp"></span><span class="hint" style="margin:0">'+(step+1)+' of 4</span><button class="btn" type="button" data-n>'+nextLabel+' '+icon("arrow")+'</button></div>';}
  function draw(){
    var h=prog();
    if(step===0){
      h+='<div class="qs-title">Let’s make every studio sound like you.</div><div class="qs-sub">Four quick questions. Everything you make reads from this, and you can change it any time.</div>'+
        '<div class="grid2"><div class="field"><label for="qsName">Your name</label><input id="qsName" value="'+esc(d.name)+'" placeholder="Yasmin Cronin"></div>'+
        '<div class="field"><label for="qsBiz">Business name</label><input id="qsBiz" value="'+esc(d.biz)+'" placeholder="Authority Builder"></div></div>'+foot("Next");
    }else if(step===1){
      h+='<div class="qs-title">What kind of business is it?</div><div class="qs-sub">This tunes the examples, the proof and the language in every template.</div><div class="qs-tiles">'+
        BIZ.map(function(b){var v=BIZ_VAL[b[0]]||b[0];return '<button type="button" class="qs-tile" data-v="'+esc(v)+'" aria-pressed="'+(d.type===v)+'">'+esc(b[0])+'<small>'+esc(b[1])+'</small></button>';}).join("")+'</div>'+foot("Next");
    }else if(step===2){
      h+='<div class="qs-title">Pick up to three archetypes.</div><div class="qs-sub">Your first pick leads (70 percent), the next two flavour it. This is how the writing finds your voice.</div><div class="qs-tiles">'+
        ARCHETYPES.map(function(a){var on=d.arcs.indexOf(a[0])>-1;return '<button type="button" class="qs-tile" data-a="'+a[0]+'" aria-pressed="'+on+'">'+a[0]+(on?' · '+(["70%","20%","10%"][d.arcs.indexOf(a[0])]):'')+'<small>'+a[1]+'</small></button>';}).join("")+'</div>'+foot("Next");
    }else{
      h+='<div class="qs-title">Choose your colours.</div><div class="qs-sub">Used in email components, brand photos and previews. Fine-tune exact hex codes later in Brand.</div><div class="qs-pals">'+
        PALETTES.slice(0,16).map(function(p){return '<button type="button" class="qs-pal" data-p="'+p.id+'" aria-pressed="'+(d.pal===p.id)+'"><span class="sw"><i style="background:'+p.bg+'"></i><i style="background:'+p.text+'"></i><i style="background:'+p.accent+'"></i><i style="background:'+p.highlight+'"></i></span><b>'+esc(p.n)+'</b></button>';}).join("")+'</div>'+foot("Finish");
    }
    body.innerHTML=h;
    var nm=body.querySelector("#qsName");if(nm)setTimeout(function(){nm.focus();},30);
    body.querySelectorAll("[data-v]").forEach(function(b){b.addEventListener("click",function(){d.type=b.dataset.v;draw();});});
    body.querySelectorAll("[data-a]").forEach(function(b){b.addEventListener("click",function(){var a=b.dataset.a,i=d.arcs.indexOf(a);if(i>-1)d.arcs.splice(i,1);else if(d.arcs.length<3)d.arcs.push(a);else toast("Three is the limit. Tap one to remove it first.");draw();});});
    body.querySelectorAll("[data-p]").forEach(function(b){b.addEventListener("click",function(){d.pal=b.dataset.p;draw();});});
    var bb=body.querySelector("[data-b]");if(bb)bb.addEventListener("click",function(){grab();step--;draw();});
    body.querySelector("[data-n]").addEventListener("click",function(){
      grab();
      if(step===0&&!d.name.trim()){toast("Add your name so emails can be signed.");return;}
      if(step===1&&!d.type){toast("Pick the closest match. You can change it later.");return;}
      if(step<3){step++;draw();return;}
      var s2=load();s2.name=d.name.trim();s2.businessName=d.biz.trim();s2.businessType=d.type;s2.archetypes=d.arcs.slice(0,3);
      if(!s2.fromName)s2.fromName=s2.name.split(" ")[0];
      var p=PALETTES.filter(function(x){return x.id===d.pal;})[0];
      if(p){s2.brand=Object.assign({},s2.brand||{},{paletteId:p.id,colors:{bg:p.bg,text:p.text,accent:p.accent,muted:p.muted,highlight:p.highlight}});s2.brandColours=brandColourLine({colors:s2.brand.colors});}
      save(s2);close();toast("Brand saved. Every studio uses it now.");
      if(typeof onDone==="function")onDone();else setTimeout(function(){location.reload();},700);
    });
  }
  function grab(){var n=body.querySelector("#qsName"),b=body.querySelector("#qsBiz");if(n)d.name=n.value;if(b)d.biz=b.value;}
  draw();m.classList.add("on");
}

/* ── template / design thumbnails (Canva-style previews) ── */
var FOLDER_TINT={
 "Start Here":["#F1F6E8","#A0CF5D"],"Welcome & Onboarding":["#EAF2DC","#A0CF5D"],"Nurture That Sells":["#F4F2E4","#C9A227"],
 "Launch & Sales":["#101D15","#B8E452"],"Challenges & Events":["#E9F0EB","#3E8E5E"],"Seasonal & Promo":["#FCEBDD","#F08A3C"],
 "Keep & Grow Your List":["#E6EEF2","#2F7FA8"],"Hooks & the AI Inbox":["#FFF6D6","#D99A00"],"Prompts & Your System":["#EFEFEA","#141B15"]};
function thumb(o){
  // o: {title, folder, count, kind:'email'|'photo'|'prompt'|'plan', badge}
  var t=FOLDER_TINT[o.folder]||["#F1F6E8","#A0CF5D"],k=o.kind||"email";
  if(k==="photo")t=["#F4F2E4","#F08A3C"];if(k==="prompt")t=["#EFEFEA","#141B15"];if(k==="plan")t=["#E9F0EB","#3E8E5E"];
  var n=Math.max(1,Math.min(3,o.count||1)),dark=t[0]==="#101D15";
  var stack=(n>2?'<span class="pg b3"></span>':'')+(n>1?'<span class="pg b2"></span>':'');
  var inner=k==="photo"
    ? '<span class="pg top photo"><i class="sun"></i><i class="head"></i><i class="body"></i><span class="cap">'+esc(o.title||"")+'</span></span>'
    : '<span class="pg top"><span class="from"><i style="background:'+t[1]+'"></i><u></u></span><span class="subj">'+esc(o.title||"")+'</span><span class="ln"></span><span class="ln"></span><span class="ln s"></span><span class="cta" style="background:'+t[1]+'"></span></span>';
  return '<span class="tthumb'+(dark?" night":"")+'" style="background:'+t[0]+(dark?';background-image:radial-gradient(rgba(160,207,93,.2) 1px,transparent 1.4px);background-size:14px 14px':'')+'">'+stack+inner+
    (o.badge?'<span class="cnt">'+esc(o.badge)+'</span>':'')+(o.icon?'<span class="ico">'+icon(o.icon)+'</span>':'')+'</span>';
}
/* ── generation library: every generation, captured per workspace ── */
function gensKey(){return "ab_gens_"+store().activeId;}
function gens(){try{return JSON.parse(localStorage.getItem(gensKey())||"[]");}catch(e){return [];}}
function logGen(entry){
  var list=gens();
  list.unshift({id:"g_"+Math.random().toString(36).slice(2,9),ts:Date.now(),
    src:entry.src||"studio",tool:entry.tool||"",title:(entry.title||"Generation").slice(0,140),
    prompt:(entry.prompt||"").slice(0,20000),text:(entry.text||"").slice(0,120000),
    json:entry.json?JSON.stringify(entry.json).slice(0,150000):""});
  list=list.slice(0,100);
  for(;;){
    try{localStorage.setItem(gensKey(),JSON.stringify(list));break;}
    catch(e){if(list.length<=1){break;} list.pop();} // storage full: drop oldest until it fits
  }
  bump("gen");
  return list[0];
}
function updateGen(id,patch){
  var list=gens(),hit=null;
  list.forEach(function(g){if(g.id===id){hit=g;
    if(patch.title!=null)g.title=String(patch.title).slice(0,140);
    if(patch.text!=null)g.text=String(patch.text).slice(0,120000);
    if(patch.json!=null)g.json=JSON.stringify(patch.json).slice(0,150000);
    g.edited=Date.now();}});
  if(hit){try{localStorage.setItem(gensKey(),JSON.stringify(list));}catch(e){return false;}}
  return !!hit;
}
function getGen(id){return gens().filter(function(g){return g.id===id;})[0]||null;}
function delGen(id){
  var list=gens().filter(function(g){return g.id!==id;});
  localStorage.setItem(gensKey(),JSON.stringify(list));
}

/* enabled custom skills → one rules block appended to every AI prompt */
function skillsBlock(){
  var sk=(load().customSkills||[]).filter(function(x){return x.on&&(x.text||"").trim();});
  if(!sk.length)return "";
  return "\n\nMY STANDING RULES (always apply):\n"+sk.map(function(x){return "- "+x.name+": "+x.text.trim();}).join("\n");
}
function token(){ return localStorage.getItem("ab_token")||""; }
function gate(){
  if(location.protocol==="file:")return;               // previews stay open
  var cached=sessionStorage.getItem("ab_gate_ok");
  if(cached==="1")return;
  fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"status"})})
   .then(function(r){return r.json();})
   .then(function(j){
     if(!j.ok||!j.authRequired){sessionStorage.setItem("ab_gate_ok","1");return;}
     var t=token();
     if(!t){location.replace(loginUrl(""));return;}
     return fetch("/api/auth",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"verify",token:t})})
      .then(function(r){return r.json();})
      .then(function(v){
        if(v.ok)sessionStorage.setItem("ab_gate_ok","1");
        else{localStorage.removeItem("ab_token");location.replace(loginUrl(v.reason==="expired"?"expired":(v.reason==="paused"?"paused":(v.reason==="ended"||v.reason==="removed"?"ended":""))));}
      });
   }).catch(function(){/* functions unreachable (local preview): stay open */});
}
/* the sign-in page sends members back to the page they were heading for */
function loginUrl(why){
  var next=location.pathname+location.search+location.hash;
  var q=[];if(next&&!/login\.html/.test(next)&&next!=="/")q.push("next="+encodeURIComponent(next));if(why)q.push(why+"=1");
  return "/login.html"+(q.length?"?"+q.join("&"):"");
}
function signOut(){
  localStorage.removeItem("ab_token"); // keep email + first name so "Welcome back" is personal; "Not you?" clears them
  sessionStorage.removeItem("ab_gate_ok");
  location.href="/login.html?out=1";
}
function toast(msg){
  var t=document.getElementById("toast");
  if(!t){t=document.createElement("div");t.id="toast";t.setAttribute("role","status");document.body.appendChild(t);}
  t.textContent=msg; t.classList.add("on");
  clearTimeout(t._t); t._t=setTimeout(function(){t.classList.remove("on");},2600);
}
function esc(x){return String(x||"").replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c];});}
apply(load());
gate();
window.AB={load:load,save:save,token:token,gate:gate,signOut:signOut,usage:usage,bump:bump,setUsage:setUsage,key:key,
  wsAll:wsAll,wsActiveId:wsActiveId,wsCreate:wsCreate,wsSwitch:wsSwitch,wsRename:wsRename,wsDelete:wsDelete,wsDuplicate:wsDuplicate,
  ARCHETYPES:ARCHETYPES,PALETTES:PALETTES,FONT_GROUPS:FONT_GROUPS,
  brand:brand,brandColourLine:brandColourLine,componentHTML:componentHTML,componentText:componentText,skillsBlock:skillsBlock,
  gens:gens,logGen:logGen,delGen:delGen,updateGen:updateGen,getGen:getGen,
  VERSION:VERSION,whatsNew:whatsNew,seenVersion:seenVersion,icon:icon,root:root,
  quickSetup:quickSetup,profileComplete:profileComplete,thumb:thumb,BIZ:BIZ,cmdHTML:cmdHTML,cmdKeys:cmdKeys,
  sidebar:sidebar,shell:sidebar,toast:toast,esc:esc,initials:initials};
})();
